#ifndef MAIN_H
#define MAIN_H

#include <stdint.h>
#include <stdbool.h>
#include "fsl_common.h"

typedef enum {
    APP_STATE_MANUAL = 0,
    APP_STATE_AUTO,
    APP_STATE_PAUSE
} app_state_t;

typedef struct {
    app_state_t current_state;
    app_state_t previous_state;
    uint32_t pwm_freq_hz;
    uint8_t manual_duty;
    uint8_t current_duty;
    int8_t auto_direction; // +1 ascendiendo, -1 descendiendo
    bool stream_enabled;
    uint32_t uptime_seconds;
    uint32_t short_press_count;
    uint32_t long_press_count;
    uint32_t error_count;
} app_context_t;

#endif /* MAIN_H */