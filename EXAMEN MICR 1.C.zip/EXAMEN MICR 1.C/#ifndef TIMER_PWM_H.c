#ifndef TIMER_PWM_H
#define TIMER_PWM_H

#include <stdint.h>
#include "fsl_common.h"

void Timer_TickInit(uint32_t timerClockHz);
uint32_t Timer_GetMs(void);
status_t Timer_PwmInit(uint32_t timerClockHz, uint32_t freqHz, uint8_t duty);
status_t Timer_PwmUpdate(uint32_t freqHz, uint8_t duty);

#endif /* TIMER_PWM_H */#include "timer_pwm.h"
#include "fsl_ctimer.h"

#define APP_TICK_TIMER      CTIMER1
#define APP_TICK_IRQn       CTIMER1_IRQn

#define APP_PWM_TIMER       CTIMER0
#define APP_PWM_PERIOD_CH   kCTIMER_Match_1
#define APP_PWM_OUTPUT_CH   kCTIMER_Match_0 /* Pin P3_12 configurado en pin_mux */

static volatile uint32_t g_ms_counter = 0;
static uint32_t s_current_pwm_freq = 1000U;

static void Tick_Callback(uint32_t flags)
{
    if (flags & kCTIMER_Match0Flag) {
        g_ms_counter++;
    }
}

static ctimer_callback_t s_tick_callbacks[] = {Tick_Callback};

void Timer_TickInit(uint32_t timerClockHz)
{
    ctimer_config_t cfg;
    ctimer_match_config_t match = {0};

    CTIMER_GetDefaultConfig(&cfg);
    cfg.prescale = 0U;
    CTIMER_Init(APP_TICK_TIMER, &cfg);

    match.matchValue = (timerClockHz / 1000U) - 1U;
    match.enableCounterReset = true;
    match.enableCounterStop = false;
    match.outControl = kCTIMER_Output_NoAction;
    match.outPinInitState = false;
    match.enableInterrupt = true;

    CTIMER_RegisterCallBack(APP_TICK_TIMER, s_tick_callbacks, kCTIMER_SingleCallback);
    CTIMER_SetupMatch(APP_TICK_TIMER, kCTIMER_Match_0, &match);
    EnableIRQ(APP_TICK_IRQn);
    CTIMER_StartTimer(APP_TICK_TIMER);
}

uint32_t Timer_GetMs(void)
{
    uint32_t ms;
    uint32_t irqState = DisableGlobalIRQ();
    ms = g_ms_counter;
    EnableGlobalIRQ(irqState);
    return ms;
}

status_t Timer_PwmInit(uint32_t timerClockHz, uint32_t freqHz, uint8_t duty)
{
    ctimer_config_t cfg;
    CTIMER_GetDefaultConfig(&cfg);
    cfg.prescale = 0U;
    CTIMER_Init(APP_PWM_TIMER, &cfg);

    s_current_pwm_freq = freqHz;
    status_t rc = CTIMER_SetupPwm(APP_PWM_TIMER, APP_PWM_PERIOD_CH, APP_PWM_OUTPUT_CH,
                                  duty, freqHz, timerClockHz, false);
    if (rc == kStatus_Success) {
        CTIMER_StartTimer(APP_PWM_TIMER);
    }
    return rc;
}

status_t Timer_PwmUpdate(uint32_t freqHz, uint8_t duty)
{
    if (freqHz != s_current_pwm_freq) {
        s_current_pwm_freq = freqHz;
        // Recalcular PWM completo si cambia la frecuencia base
        // (Asume reloj fijo del periférico)
    }
    return CTIMER_UpdatePwmDutycycle(APP_PWM_TIMER, APP_PWM_PERIOD_CH, APP_PWM_OUTPUT_CH, duty);
}