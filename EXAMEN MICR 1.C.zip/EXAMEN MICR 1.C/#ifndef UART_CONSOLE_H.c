#ifndef UART_CONSOLE_H
#define UART_CONSOLE_H

#include "main.h"

void Console_Init(void);
void Console_Process(app_context_t *ctx);
void Console_Write(const char *str);

#endif /* UART_CONSOLE_H */#include "uart_console.h"
#include "fsl_debug_console.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define UART_LINE_MAX_LEN 63

static char s_line_buf[UART_LINE_MAX_LEN + 1];
static uint8_t s_line_len = 0;
static bool s_overflow_flag = false;

void Console_Init(void)
{
    BOARD_InitDebugConsole();
}

void Console_Write(const char *str)
{
    PRINTF("%s", str);
}

static void TrimWhitespace(char *str)
{
    char *end;
    while (*str == ' ' || *str == '\t') str++;
    if (*str == 0) return;
    end = str + strlen(str) - 1;
    while (end > str && (*end == ' ' || *end == '\t' || *end == '\r' || *end == '\n')) end--;
    *(end + 1) = '\0';
}

static void ExecuteCommand(const char *cmd, app_context_t *ctx)
{
    if (strcmp(cmd, "HELP") == 0) {
        Console_Write("OK: HELP, STATUS, MODE MANUAL, MODE AUTO, DUTY n, FREQ n, PAUSE, RESUME, STREAM ON/OFF\r\n");
    } else if (strcmp(cmd, "STATUS") == 0) {
        char buf[128];
        const char *m_str = (ctx->current_state == APP_STATE_MANUAL) ? "MANUAL" :
                            (ctx->current_state == APP_STATE_AUTO) ? "AUTO" : "PAUSE";
        snprintf(buf, sizeof(buf), "OK STATUS: Mode=%s, Freq=%lu Hz, Duty=%d%%, ManualDuty=%d%%, Uptime=%lu s, Short=%lu, Long=%lu, Err=%lu\r\n",
                 m_str, ctx->pwm_freq_hz, ctx->current_duty, ctx->manual_duty, ctx->uptime_seconds,
                 ctx->short_press_count, ctx->long_press_count, ctx->error_count);
        Console_Write(buf);
    } else if (strcmp(cmd, "MODE MANUAL") == 0) {
        if (ctx->current_state == APP_STATE_PAUSE) {
            Console_Write("ERR STATE\r\n");
            ctx->error_count++;
            return;
        }
        ctx->current_state = APP_STATE_MANUAL;
        ctx->current_duty = ctx->manual_duty;
        Console_Write("OK\r\n");
    } else if (strcmp(cmd, "MODE AUTO") == 0) {
        if (ctx->current_state == APP_STATE_PAUSE) {
            Console_Write("ERR STATE\r\n");
            ctx->error_count++;
            return;
        }
        ctx->current_state = APP_STATE_AUTO;
        ctx->current_duty = 10U;
        ctx->auto_direction = 1;
        Console_Write("OK\r\n");
    } else if (strncmp(cmd, "DUTY ", 5) == 0) {
        if (ctx->current_state != APP_STATE_MANUAL) {
            Console_Write("ERR STATE\r\n");
            ctx->error_count++;
            return;
        }
        char *endptr;
        long val = strtol(cmd + 5, &endptr, 10);
        if (endptr == (cmd + 5) || *endptr != '\0' || val < 0 || val > 100) {
            Console_Write("ERR RANGE\r\n");
            ctx->error_count++;
            return;
        }
        ctx->manual_duty = (uint8_t)val;
        ctx->current_duty = ctx->manual_duty;
        Console_Write("OK\r\n");
    } else if (strncmp(cmd, "FREQ ", 5) == 0) {
        if (ctx->current_state == APP_STATE_PAUSE) {
            Console_Write("ERR STATE\r\n");
            ctx->error_count++;
            return;
        }
        char *endptr;
        long val = strtol(cmd + 5, &endptr, 10);
        if (endptr == (cmd + 5) || *endptr != '\0' || (val != 500 && val != 1000 && val != 2000)) {
            Console_Write("ERR RANGE\r\n");
            ctx->error_count++;
            return;
        }
        ctx->pwm_freq_hz = (uint32_t)val;
        Console_Write("OK\r\n");
    } else if (strcmp(cmd, "PAUSE") == 0) {
        if (ctx->current_state != APP_STATE_PAUSE) {
            ctx->previous_state = ctx->current_state;
            ctx->current_state = APP_STATE_PAUSE;
        }
        Console_Write("OK\r\n");
    } else if (strcmp(cmd, "RESUME") == 0) {
        if (ctx->current_state == APP_STATE_PAUSE) {
            ctx->current_state = ctx->previous_state;
            Console_Write("OK\r\n");
        } else {
            Console_Write("ERR STATE\r\n");
            ctx->error_count++;
        }
    } else if (strcmp(cmd, "STREAM ON") == 0) {
        ctx->stream_enabled = true;
        Console_Write("OK\r\n");
    } else if (strcmp(cmd, "STREAM OFF") == 0) {
        ctx->stream_enabled = false;
        Console_Write("OK\r\n");
    } else {
        Console_Write("ERR COMMAND\r\n");
        ctx->error_count++;
    }
}

void Console_Process(app_context_t *ctx)
{
    int c = GETCHAR_NON_BLOCKING(); // O lectura desde búfer circular
    while (c != EOF) {
        char ch = (char)c;
        if (ch == '\r' || ch == '\n') {
            if (s_line_len > 0) {
                s_line_buf[s_line_len] = '\0';
                TrimWhitespace(s_line_buf);
                if (s_overflow_flag) {
                    Console_Write("ERR OVERFLOW\r\n");
                    ctx->error_count++;
                    s_overflow_flag = false;
                } else {
                    ExecuteCommand(s_line_buf, ctx);
                }
                s_line_len = 0;
            }
        } else {
            if (s_line_len < UART_LINE_MAX_LEN) {
                s_line_buf[s_line_len++] = ch;
            } else {
                s_overflow_flag = true;
            }
        }
        c = GETCHAR_NON_BLOCKING();
    }
}