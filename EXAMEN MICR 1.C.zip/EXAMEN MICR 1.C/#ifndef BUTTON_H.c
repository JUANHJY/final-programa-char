#ifndef BUTTON_H
#define BUTTON_H

#include <stdbool.h>

void Button_Init(void);
void Button_Process1Ms(void);
bool Button_GetShortPress(void);
bool Button_GetLongPress(void);

#endif /* BUTTON_H */#include "button.h"
#include "fsl_gpio.h"
#include "board.h"

/* Ajustar según board.h de la FRDM-MCXA156 */
#ifndef APP_BTN_GPIO
#define APP_BTN_GPIO   GPIOA
#define APP_BTN_PIN    4U
#define APP_BTN_IRQn   GPIOA_IRQn
#endif

static volatile uint32_t g_buttonEdgePending = 0;
static uint8_t s_debounce_counter = 0;
static bool s_pin_stable_state = true; // Pull-up activo (1 en reposo)
static uint16_t s_press_duration_ms = 0;
static bool s_press_counted_long = false;

static bool s_short_press_event = false;
static bool s_long_press_event = false;

void Button_Init(void)
{
    gpio_pin_config_t btn_config = {kGPIO_DigitalInput, 0U};
    GPIO_PortInit(APP_BTN_GPIO);
    GPIO_PinInit(APP_BTN_GPIO, APP_BTN_PIN, &btn_config);
    GPIO_SetPinInterruptChannel(APP_BTN_GPIO, APP_BTN_PIN, kGPIO_InterruptOutput0);
    GPIO_GpioClearInterruptFlags(APP_BTN_GPIO, 1UL << APP_BTN_PIN);
    GPIO_SetPinInterruptConfig(APP_BTN_GPIO, APP_BTN_PIN, kGPIO_InterruptEitherEdge);
    EnableIRQ(APP_BTN_IRQn);
}

void APP_BTN_IRQHandler(void)
{
    uint32_t mask = 1UL << APP_BTN_PIN;
    if (GPIO_GpioGetInterruptFlags(APP_BTN_GPIO) & mask) {
        GPIO_GpioClearInterruptFlags(APP_BTN_GPIO, mask);
        g_buttonEdgePending = 1U;
    }
    SDK_ISR_EXIT_BARRIER;
}

void Button_Process1Ms(void)
{
    bool pin_level = (GPIO_PinRead(APP_BTN_GPIO, APP_BTN_PIN) != 0U);

    if (g_buttonEdgePending != 0U) {
        g_buttonEdgePending = 0U;
        s_debounce_counter = 0U;
    }

    if (pin_level != s_pin_stable_state) {
        s_debounce_counter++;
        if (s_debounce_counter >= 30U) { // 30 ms de estabilidad requerida
            s_pin_stable_state = pin_level;
            s_debounce_counter = 0U;

            if (!s_pin_stable_state) {
                s_press_duration_ms = 0;
                s_press_counted_long = false;
            } else {
                if (!s_press_counted_long) {
                    if (s_press_duration_ms >= 30U && s_press_duration_ms < 1500U) {
                        s_short_press_event = true;
                    }
                }
            }
        }
    } else {
        s_debounce_counter = 0U;
        if (!s_pin_stable_state) {
            s_press_duration_ms++;
            if (s_press_duration_ms >= 1500U && !s_press_counted_long) {
                s_long_press_event = true;
                s_press_counted_long = true;
            }
        }
    }
}

bool Button_GetShortPress(void)
{
    bool val = s_short_press_event;
    s_short_press_event = false;
    return val;
}

bool Button_GetLongPress(void)
{
    bool val = s_long_press_event;
    s_long_press_event = false;
    return val;
}