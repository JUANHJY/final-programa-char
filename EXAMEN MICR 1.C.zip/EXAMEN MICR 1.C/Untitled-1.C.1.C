#include <stdio.h>
#include "fsl_device_registers.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "board.h"
#include "fsl_debug_console.h"

int main(void)
{
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitDebugConsole();

    PRINTF("Hito 1: Proyecto inicializado y consola lista.\r\n");

    for (;;) {
        // Bucle vacío por ahora
    }
}